<!DOCTYPE html>
<head>
    <meta charset="UTF-8">
    <link type="text/css" rel="stylesheet" href="{{url('assets/css/style.css')}}">
    <title>Relatórios</title>
</head>
<body>
    <section class="area-relatorios">
        <div class="relatorios">
            <div>
            <img src="{!! asset('assets/img/img.png') !!}">
            </div>

            <form method="post">
                <input type="text" name="Relatórios" placeholder="Relatórios" autocomplete="off">
                <input type="submit6" value="Imprimir">
            </form>
        </div>
    </section>
</body>

</html>
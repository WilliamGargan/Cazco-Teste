<!DOCTYPE html>
<head>
    <meta charset="UTF-8">
    <link type="text/css" rel="stylesheet" href="<?php echo e(url('assets/css/style.css')); ?>">
    <title>Login</title>
</head>
<body>
    <section class="area-login">
        <div class="login">
            <div>
            <img src="<?php echo asset('assets/img/img.png'); ?>">
            </div>

            <form method="post">
                <input type="text" name="Email" placeholder="Email" autocomplete="off">
                <input type="password" name="senha" placeholder="Senha">
                <input type="submit" value="entrar">
            </form>
            <p>Esqueci Minha Senha?<a href="/user/forgotpassword" href="/admin/forgotpassword">Recuperar Senha</a></p>
        </div>
    </section>
</body>

</html><?php /**PATH C:\Users\pipei\OneDrive\Área de Trabalho\Projeto Cazco\example-app\resources\views/frontend/Login.blade.php ENDPATH**/ ?>
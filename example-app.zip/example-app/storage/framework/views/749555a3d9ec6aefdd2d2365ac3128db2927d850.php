<!DOCTYPE html>
<head>
    <meta charset="UTF-8">
    <link type="text/css" rel="stylesheet" href="<?php echo e(url('assets/css/style.css')); ?>">
    <title>Relatórios</title>
</head>
<body>
    <section class="area-relatorios">
        <div class="relatorios">
            <div>
            <img src="<?php echo asset('assets/img/img.png'); ?>">
            </div>

            <form method="post">
                <input type="text" name="Relatórios" placeholder="Relatórios" autocomplete="off">
                <input type="submit6" value="Imprimir">
            </form>
        </div>
    </section>
</body>

</html><?php /**PATH C:\Users\pipei\OneDrive\Área de Trabalho\Projeto Cazco\example-app\resources\views/frontend/reports-users.blade.php ENDPATH**/ ?>
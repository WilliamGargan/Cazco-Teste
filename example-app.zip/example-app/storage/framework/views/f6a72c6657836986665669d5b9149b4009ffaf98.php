<!DOCTYPE html>
<head>
    <meta charset="UTF-8">
    <link rel="stylesheet" href="<?php echo e(url('assets/css/style.css')); ?>">
    <title>Recuperação de Senha</title>
</head>
<body>
    <section class="area-senha">
        <div class="senha">
            <div>
                <img src="<?php echo asset('assets/img/img.png'); ?>">
            </div>

            <form method="post">
                <input type="password" name="Nova Senha" placeholder="Nova Senha">
                <input type="password" name="Confirmar Nova Senha" placeholder="Confirmar Nova Senha">
                <input type="submit3" value="Enviar">
            </form>
        </div>
    </section>
</body>

</html><?php /**PATH C:\Users\pipei\OneDrive\Área de Trabalho\Projeto Cazco\example-app\resources\views/frontend/passwordrecovery.blade.php ENDPATH**/ ?>
<!DOCTYPE html>
<head>
    <meta charset="UTF-8">
    <link rel="stylesheet" href="<?php echo e(url('assets/css/style2.css')); ?>">
    <title>Lista de Usuários</title>
</head>

<body>
    <table>
        <caption><b>Lista de Usuários</b></caption>
        <th>ID</th>
        <th>Nome</th>
        <th>Email</th>
        <th colspan="3">Ações</th>

        <tr>
            <td>1</td>
            <td>Marcos</td>
            <td>marcos.gg@gmail.com</td>
            <td><button><a href="">Relatórios</a></button><button><a href="/admin/edit">Editar</a></button><button><a href="">Excluir</a></button></td>
        </tr>

        <tr>
            <td>2</td>
            <td>Luana</td>
            <td>luana.lu@gmail.com</td>
            <td><button><a href="">Relatórios</a></button><button><a href="/admin/edit">Editar</a></button><button><a href="">Excluir</a></button></td>
        </tr>

        <tr>
            <td>3</td>
            <td>Carlos</td>
            <td>carlos.caca@gmail.com</td>
            <td><button><a href="">Relatórios</a></button><button><a href="/admin/edit">Editar</a></button><button><a href="">Excluir</a></button></td>
        </tr>
    </table>
</body>

    <p><button><a href="/admin/create">Novo Usuário</a></button></p>
</html><?php /**PATH C:\Users\pipei\OneDrive\Área de Trabalho\Projeto Cazco\example-app\resources\views/frontend/listusers.blade.php ENDPATH**/ ?>
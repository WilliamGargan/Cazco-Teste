<!DOCTYPE html>
<head>
    <meta charset="UTF-8">
    <link rel="stylesheet" href="<?php echo e(url('assets/css/style.css')); ?>">
    <title>Esqueci Minha Senha</title>
</head>
<body>
    <section class="area-email">
        <div class="email">
            <div>
                <img src="<?php echo asset('assets/img/img.png'); ?>">
            </div>

            <form method="post">
                <input type="text" name="Email" placeholder="Email" autocomplete="off" style="width: 320px;">
                <input type="submit2" value="enviar" style="width: 120px;">
            </form>
        </div>
    </section>
</body>
</html><?php /**PATH C:\Users\pipei\OneDrive\Área de Trabalho\Projeto Cazco\example-app\resources\views/frontend/forgot-password.blade.php ENDPATH**/ ?>